DROP TABLE IF EXISTS sections;
DROP TABLE IF EXISTS soes;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS document;


-- proceedings.document definition
CREATE TABLE document (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255),
  description varchar(255),
  status int(11),
  format varchar(255),
  required int(11),
  limit_mb int(11),
  docwkf int(11),
  tipo int(11),
  fecha timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  id_sub int(11),
  PRIMARY KEY (id)
) ENGINE=InnoDB ;


-- proceedings.products definition
CREATE TABLE products (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255),
  description varchar(255),
  fecha timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB;

-- proceedings.soes definition
CREATE TABLE soes (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255),
  description varchar(255),
  code varchar(16),
  xyear varchar(6),
  version varchar(16),
  id_product int(11),
  fecha timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (id),
  KEY id_product (id_product),
  CONSTRAINT soes_ibfk_1 FOREIGN KEY (id_product) REFERENCES products (id)
) ENGINE=InnoDB;

-- proceedings.sections definition
CREATE TABLE sections (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255),
  description varchar(255),
  id_soe int(11),
  fecha timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (id),
  KEY id_soe (id_soe),
  CONSTRAINT sections_ibfk_1 FOREIGN KEY (id_soe) REFERENCES soes (id)
) ENGINE=InnoDB ;